
public class UpdateMonitor implements Runnable {

	public ServerMulticast mUtil;
	
	public UpdateMonitor(ServerMulticast m){
		mUtil = m;
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		//mUtil.sendString("update);
	}

}
